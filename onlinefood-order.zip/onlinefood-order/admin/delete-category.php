<?php 
include('../config/constants.php');

if(isset($_GET['id']) AND isset($_GET['image_name']))
{
    $id = $_GET['id'];
    $image_name = $_GET['image_name'];

    if(isset($_GET['confirm']) && $_GET['confirm'] === 'true') {
        // The user has confirmed the delete action

        if($image_name != "")
        {
            $path = "../images/category/".$image_name;
            
            $remove = unlink($path);

            if($remove == false)
            {
                $_SESSION['remove'] = "<div class='error'>Failed to Remove Category Image.</div>";
                header('location:'.SITEURL.'admin/manage-category.php');
                die();
            }
        }

        $sql = "DELETE FROM tbl_category WHERE id=$id";
        $res = mysqli_query($conn, $sql);

        if($res == true)
        {
            $_SESSION['delete'] = "<div class='success'>Category Deleted Successfully.</div>";
            header('location:'.SITEURL.'admin/manage-category.php');
        }
        else
        {
            $_SESSION['delete'] = "<div class='error'>Failed to Delete Category.</div>";
            header('location:'.SITEURL.'admin/manage-category.php');
        }
    }
    else
    {
        // Show a confirmation dialog using JavaScript
        echo '<script>
            if (confirm("Are you sure you want to delete this category?")) {
                window.location.href = "'.SITEURL.'admin/delete-category.php?id='.$id.'&image_name='.$image_name.'&confirm=true";
            } else {
                window.location.href = "'.SITEURL.'admin/manage-category.php";
            }
        </script>';
    }
}
else
{
    header('location:'.SITEURL.'admin/manage-category.php');
}
?>
